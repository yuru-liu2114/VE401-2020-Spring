import numpy as np
import pandas as pd
import math

data = {'Poor': [1,12,12],
        'Fair': [3,28,14],
        'Good': [24,76,30]}
df = pd.DataFrame(data)
matrix=df.values
df['Col_sum'] = df.apply(lambda x: x.sum(), axis=1)
df.loc['Row_sum'] = df.apply(lambda x: x.sum())
matrix_observed=df.values
total = matrix_observed[3][3]#第一个为行，第二个为列索引
print(matrix_observed)
data_expected = {'Poor': [matrix_observed[0][3]*matrix_observed[3][0]/total, matrix_observed[1][3]*matrix_observed[3][0]/total, matrix_observed[2][3]*matrix_observed[3][0]/total], #row 1
                 'Fair': [matrix_observed[0][3]*matrix_observed[3][1]/total, matrix_observed[1][3]*matrix_observed[3][1]/total, matrix_observed[2][3]*matrix_observed[3][1]/total],
                 'Good': [matrix_observed[0][3]*matrix_observed[3][2]/total, matrix_observed[1][3]*matrix_observed[3][2]/total, matrix_observed[2][3]*matrix_observed[3][2]/total]}
df2=pd.DataFrame(data_expected)
matrix_expected = df2.values
statistic=np.sum((matrix-matrix_expected)**2/matrix_expected)
print(statistic)
